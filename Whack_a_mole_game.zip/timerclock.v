`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 24.10.2025 18:05:36
// Design Name: 
// Module Name: main
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

//1Hz clock, 1 second
module timerclock(
    input clk_in,      // 100 MHz input clock
    output reg clk_out // 1 Hz output clock
);

    reg [27:0] period_count = 0;

    always @(posedge clk_in) begin
        if(period_count  != 100_000_000-1)
         begin
           period_count<=period_count+1;
	   clk_out<=0;
        end
        else begin
            period_count <=0;
	    clk_out<=1;
        end
    end
endmodule