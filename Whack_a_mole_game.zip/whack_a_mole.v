`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 26.10.2025
// Design Name: Whack-a-Mole Game Logic
// Module Name: whack_a_mole_game
// Project Name: Digital Programming Project
// Target Devices: FPGA Board
// Description: Whack-a-Mole FSM with alternate edge detection per LED
//////////////////////////////////////////////////////////////////////////////////

module whack_a_mole_game(
    input clk,
    input [15:0] sw,           // Switches used for whack-a-mole
    input reset,               // To reset the game
    input [4:0] timer_count,
    output reg [5:0] score_count, // Maximum score count is 32
    output reg [15:0] led       // LEDs represent moles
);

    // State encoding
    localparam 
        s000000 = 0, s000001 = 1, s000010 = 2, s000011 = 3, s000100 = 4,
        s000101 = 5, s000110 = 6, s000111 = 7, s001000 = 8, s001001 = 9,
        s001010 = 10, s001011 = 11, s001100 = 12, s001101 = 13, s001110 = 14,
        s001111 = 15, s010000 = 16, s010001 = 17, s010010 = 18, s010011 = 19,
        s010100 = 20, s010101 = 21, s010110 = 22, s010111 = 23, s011000 = 24,
        s011001 = 25, s011010 = 26, s011011 = 27, s011100 = 28, s011101 = 29,
        s011110 = 30, s011111 = 31, s100000 = 32;

    reg [5:0] current_state;

    reg [15:0] sw_prev;    // store previous switch states
    reg [15:0] edge_flag;  // 0=rising edge next, 1=falling edge next

    // Sequential FSM + edge detection
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            current_state <= s000000;
            score_count <= 0;
            led <= 16'b0;
            sw_prev <= 16'b0;
            edge_flag <= 16'b0; // first press is rising edge
        end else begin
            sw_prev <= sw;    // update previous switch states
            led <= 16'b0;     // default all LEDs off

         if (timer_count == 0) begin
                // Timer is zero, turn off all LEDs
                led <= 16'b0;
            end else begin
                led <= 16'b0; // default all off, set active LED below
                
            case (current_state)
                s000000: begin
                    led[3] <= 1'b1; score_count <= 0;
                    if ((edge_flag[3]==0 && sw[3] & ~sw_prev[3]) ||
                        (edge_flag[3]==1 && ~sw[3] & sw_prev[3])) begin
                        current_state <= s000001;
                        edge_flag[3] <= ~edge_flag[3];
                    end
                end
                s000001: begin
                    led[7] <= 1'b1; score_count <= 1;
                    if ((edge_flag[7]==0 && sw[7] & ~sw_prev[7]) ||
                        (edge_flag[7]==1 && ~sw[7] & sw_prev[7])) begin
                        current_state <= s000010;
                        edge_flag[7] <= ~edge_flag[7];
                    end
                end
                s000010: begin
                    led[12] <= 1'b1; score_count <= 2;
                    if ((edge_flag[12]==0 && sw[12] & ~sw_prev[12]) ||
                        (edge_flag[12]==1 && ~sw[12] & sw_prev[12])) begin
                        current_state <= s000011;
                        edge_flag[12] <= ~edge_flag[12];
                    end
                end
                s000011: begin
                    led[0] <= 1'b1; score_count <= 3;
                    if ((edge_flag[0]==0 && sw[0] & ~sw_prev[0]) ||
                        (edge_flag[0]==1 && ~sw[0] & sw_prev[0])) begin
                        current_state <= s000100;
                        edge_flag[0] <= ~edge_flag[0];
                    end
                end
                s000100: begin
                    led[5] <= 1'b1; score_count <= 4;
                    if ((edge_flag[5]==0 && sw[5] & ~sw_prev[5]) ||
                        (edge_flag[5]==1 && ~sw[5] & sw_prev[5])) begin
                        current_state <= s000101;
                        edge_flag[5] <= ~edge_flag[5];
                    end
                end
                s000101: begin
                    led[14] <= 1'b1; score_count <= 5;
                    if ((edge_flag[14]==0 && sw[14] & ~sw_prev[14]) ||
                        (edge_flag[14]==1 && ~sw[14] & sw_prev[14])) begin
                        current_state <= s000110;
                        edge_flag[14] <= ~edge_flag[14];
                    end
                end
                s000110: begin
                    led[1] <= 1'b1; score_count <= 6;
                    if ((edge_flag[1]==0 && sw[1] & ~sw_prev[1]) ||
                        (edge_flag[1]==1 && ~sw[1] & sw_prev[1])) begin
                        current_state <= s000111;
                        edge_flag[1] <= ~edge_flag[1];
                    end
                end
                s000111: begin
                    led[9] <= 1'b1; score_count <= 7;
                    if ((edge_flag[9]==0 && sw[9] & ~sw_prev[9]) ||
                        (edge_flag[9]==1 && ~sw[9] & sw_prev[9])) begin
                        current_state <= s001000;
                        edge_flag[9] <= ~edge_flag[9];
                    end
                end
                s001000: begin
                    led[11] <= 1'b1; score_count <= 8;
                    if ((edge_flag[11]==0 && sw[11] & ~sw_prev[11]) ||
                        (edge_flag[11]==1 && ~sw[11] & sw_prev[11])) begin
                        current_state <= s001001;
                        edge_flag[11] <= ~edge_flag[11];
                    end
                end
                s001001: begin
                    led[2] <= 1'b1; score_count <= 9;
                    if ((edge_flag[2]==0 && sw[2] & ~sw_prev[2]) ||
                        (edge_flag[2]==1 && ~sw[2] & sw_prev[2])) begin
                        current_state <= s001010;
                        edge_flag[2] <= ~edge_flag[2];
                    end
                end
                s001010: begin
                    led[8] <= 1'b1; score_count <= 10;
                    if ((edge_flag[8]==0 && sw[8] & ~sw_prev[8]) ||
                        (edge_flag[8]==1 && ~sw[8] & sw_prev[8])) begin
                        current_state <= s001011;
                        edge_flag[8] <= ~edge_flag[8];
                    end
                end
                s001011: begin
                    led[6] <= 1'b1; score_count <= 11;
                    if ((edge_flag[6]==0 && sw[6] & ~sw_prev[6]) ||
                        (edge_flag[6]==1 && ~sw[6] & sw_prev[6])) begin
                        current_state <= s001100;
                        edge_flag[6] <= ~edge_flag[6];
                    end
                end
                s001100: begin
                    led[13] <= 1'b1; score_count <= 12;
                    if ((edge_flag[13]==0 && sw[13] & ~sw_prev[13]) ||
                        (edge_flag[13]==1 && ~sw[13] & sw_prev[13])) begin
                        current_state <= s001101;
                        edge_flag[13] <= ~edge_flag[13];
                    end
                end
                s001101: begin
                    led[4] <= 1'b1; score_count <= 13;
                    if ((edge_flag[4]==0 && sw[4] & ~sw_prev[4]) ||
                        (edge_flag[4]==1 && ~sw[4] & sw_prev[4])) begin
                        current_state <= s001110;
                        edge_flag[4] <= ~edge_flag[4];
                    end
                end
                s001110: begin
                    led[15] <= 1'b1; score_count <= 14;
                    if ((edge_flag[15]==0 && sw[15] & ~sw_prev[15]) ||
                        (edge_flag[15]==1 && ~sw[15] & sw_prev[15])) begin
                        current_state <= s001111;
                        edge_flag[15] <= ~edge_flag[15];
                    end
                end
                s001111: begin
                    led[10] <= 1'b1; score_count <= 15;
                    if ((edge_flag[10]==0 && sw[10] & ~sw_prev[10]) ||
                        (edge_flag[10]==1 && ~sw[10] & sw_prev[10])) begin
                        current_state <= s010000;
                        edge_flag[10] <= ~edge_flag[10];
                    end
                end
                s010000: begin
                    led[1] <= 1'b1; score_count <= 16;
                    if ((edge_flag[1]==0 && sw[1] & ~sw_prev[1]) ||
                        (edge_flag[1]==1 && ~sw[1] & sw_prev[1])) begin
                        current_state <= s010001;
                        edge_flag[1] <= ~edge_flag[1];
                    end
                end
                s010001: begin
                    led[11] <= 1'b1; score_count <= 17;
                    if ((edge_flag[11]==0 && sw[11] & ~sw_prev[11]) ||
                        (edge_flag[11]==1 && ~sw[11] & sw_prev[11])) begin
                        current_state <= s010010;
                        edge_flag[11] <= ~edge_flag[11];
                    end
                end
                s010010: begin
                    led[6] <= 1'b1; score_count <= 18;
                    if ((edge_flag[6]==0 && sw[6] & ~sw_prev[6]) ||
                        (edge_flag[6]==1 && ~sw[6] & sw_prev[6])) begin
                        current_state <= s010011;
                        edge_flag[6] <= ~edge_flag[6];
                    end
                end
                s010011: begin
                    led[0] <= 1'b1; score_count <= 19;
                    if ((edge_flag[0]==0 && sw[0] & ~sw_prev[0]) ||
                        (edge_flag[0]==1 && ~sw[0] & sw_prev[0])) begin
                        current_state <= s010100;
                        edge_flag[0] <= ~edge_flag[0];
                    end
                end
                s010100: begin
                    led[7] <= 1'b1; score_count <= 20;
                    if ((edge_flag[7]==0 && sw[7] & ~sw_prev[7]) ||
                        (edge_flag[7]==1 && ~sw[7] & sw_prev[7])) begin
                        current_state <= s010101;
                        edge_flag[7] <= ~edge_flag[7];
                    end
                end
                s010101: begin
                    led[14] <= 1'b1; score_count <= 21;
                    if ((edge_flag[14]==0 && sw[14] & ~sw_prev[14]) ||
                        (edge_flag[14]==1 && ~sw[14] & sw_prev[14])) begin
                        current_state <= s010110;
                        edge_flag[14] <= ~edge_flag[14];
                    end
                end
                s010110: begin
                    led[3] <= 1'b1; score_count <= 22;
                    if ((edge_flag[3]==0 && sw[3] & ~sw_prev[3]) ||
                        (edge_flag[3]==1 && ~sw[3] & sw_prev[3])) begin
                        current_state <= s010111;
                        edge_flag[3] <= ~edge_flag[3];
                    end
                end
                s010111: begin
                    led[9] <= 1'b1; score_count <= 23;
                    if ((edge_flag[9]==0 && sw[9] & ~sw_prev[9]) ||
                        (edge_flag[9]==1 && ~sw[9] & sw_prev[9])) begin
                        current_state <= s011000;
                        edge_flag[9] <= ~edge_flag[9];
                    end
                end
                s011000: begin
                    led[12] <= 1'b1; score_count <= 24;
                    if ((edge_flag[12]==0 && sw[12] & ~sw_prev[12]) ||
                        (edge_flag[12]==1 && ~sw[12] & sw_prev[12])) begin
                        current_state <= s011001;
                        edge_flag[12] <= ~edge_flag[12];
                    end
                end
                s011001: begin
                    led[5] <= 1'b1; score_count <= 25;
                    if ((edge_flag[5]==0 && sw[5] & ~sw_prev[5]) ||
                        (edge_flag[5]==1 && ~sw[5] & sw_prev[5])) begin
                        current_state <= s011010;
                        edge_flag[5] <= ~edge_flag[5];
                    end
                end
                s011010: begin
                    led[2] <= 1'b1; score_count <= 26;
                    if ((edge_flag[2]==0 && sw[2] & ~sw_prev[2]) ||
                        (edge_flag[2]==1 && ~sw[2] & sw_prev[2])) begin
                        current_state <= s011011;
                        edge_flag[2] <= ~edge_flag[2];
                    end
                end
                s011011: begin
                    led[8] <= 1'b1; score_count <= 27;
                    if ((edge_flag[8]==0 && sw[8] & ~sw_prev[8]) ||
                        (edge_flag[8]==1 && ~sw[8] & sw_prev[8])) begin
                        current_state <= s011100;
                        edge_flag[8] <= ~edge_flag[8];
                    end
                end
                s011100: begin
                    led[15] <= 1'b1; score_count <= 28;
                    if ((edge_flag[15]==0 && sw[15] & ~sw_prev[15]) ||
                        (edge_flag[15]==1 && ~sw[15] & sw_prev[15])) begin
                        current_state <= s011101;
                        edge_flag[15] <= ~edge_flag[15];
                    end
                end
                s011101: begin
                    led[13] <= 1'b1; score_count <= 29;
                    if ((edge_flag[13]==0 && sw[13] & ~sw_prev[13]) ||
                        (edge_flag[13]==1 && ~sw[13] & sw_prev[13])) begin
                        current_state <= s011110;
                        edge_flag[13] <= ~edge_flag[13];
                    end
                end
                s011110: begin
                    led[4] <= 1'b1; score_count <= 30;
                    if ((edge_flag[4]==0 && sw[4] & ~sw_prev[4]) ||
                        (edge_flag[4]==1 && ~sw[4] & sw_prev[4])) begin
                        current_state <= s011111;
                        edge_flag[4] <= ~edge_flag[4];
                    end
                end
                s011111: begin
                    led[10] <= 1'b1; score_count <= 31;
                    if ((edge_flag[10]==0 && sw[10] & ~sw_prev[10]) ||
                        (edge_flag[10]==1 && ~sw[10] & sw_prev[10])) begin
                        current_state <= s100000;
                        edge_flag[10] <= ~edge_flag[10];
                    end
                end
                s100000: begin
                    led <= 16'b0;        // all LEDs off
                    score_count <= 32;   // max score
                    current_state <= s100000;
                end
                default: current_state <= s000000;
            endcase
        end
    end
    
   end
endmodule
