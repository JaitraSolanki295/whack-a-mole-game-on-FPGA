`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 25.10.2025
// Design Name: Whack-a-Mole Game
// Module Name: main_whack_a_mole_top
// Target Devices: Basys3 FPGA Board
// Description: Top module integrating timer, whack-a-mole game, BCD display, and 7-segment interface.
// 
//////////////////////////////////////////////////////////////////////////////////

module main_whack_a_mole_top(
    input clk,              // 100 MHz Basys3 clock
    input reset,            // reset push button
    input [15:0] sw,        // player inputs (switches)
    output [15:0] led,      // LED outputs (moles)
    output [6:0] seg,       // 7-segment segments
    output [7:0] an         // 7-segment anodes
);

    //==============================
    // Internal wire declarations
    //==============================
    wire clk_100hz;          // Slow clock (100Hz)
    wire [1:0] mux_sel;      // 2-bit counter output
    wire [3:0] mux_out;      // MUX output for BCD
    wire [3:0] score_ones, score_tens;
    wire [1:0] score_hundreds;
    wire [5:0] score;        // Score from whack-a-mole (max 32)
    wire [4:0] timer_count;  // 20-second countdown timer
    wire [3:0] timer_ones, timer_tens;
    wire [3:0] zeros = 4'b0000; // constant zeros

    //==============================
    // Instantiate Timer Counter (20s countdown)
    //==============================
    timercount T1 (
        .clk(clk),
        .reset(reset),
        .count(timer_count)
    );

    //==============================
    // Instantiate Whack-a-Mole Game
    //==============================
    whack_a_mole_game G1 (
        .clk(clk_100hz),      // using 100Hz slow clock for visible reaction
        .sw(sw),
        .reset(reset),
        .timer_count(timer_count),
        .score_count(score),
        .led(led)
    );

    //==============================
    // Binary to BCD Conversion for Timer and Score
    //==============================
    // Convert 20s timer count (5-bit) to BCD
    BCD_Binary_Converter B1 (
        .A({3'b000, timer_count}), // extend to 8 bits
        .ones(timer_ones),
        .tens(timer_tens),
        .hundreds()
    );

    // Convert Score (6-bit) to BCD
    BCD_Binary_Converter B2 (
        .A({2'b00, score}),  // extend to 8 bits
        .ones(score_ones),
        .tens(score_tens),
        .hundreds(score_hundreds)
    );

    //==============================
    // 4-to-1 MUX: Select display digits
    //==============================
    four_one_mux M1 (
        .A(score_ones),         // 2 rightmost digits → score
        .B(score_tens),
        .C(timer_ones),         // 2 leftmost digits → timer
        .D(timer_tens),
        .SS(mux_sel),
        .Y(mux_out)
    );

    //==============================
    // Slow Clock Generator (100Hz)
    //==============================
    Slow_Clock S1 (
        .clk_in(clk),
        .clk_out(clk_100hz)
    );

    //==============================
    // 2-bit Counter (for 4-digit multiplexing)
    //==============================
    two_bit_counter C1 (
        .clk(clk_100hz),
        .Q(mux_sel)
    );

    //==============================
    // Decoder (for anode selection)
    //==============================
    decoder2to8 D1 (
        .en(mux_sel),
        .an(an)
    );

    //==============================
    // BCD to 7-Segment Display Driver
    //==============================
    BCD_SevenSegment S2 (
        .Y(mux_out),
        .disp(seg)
    );

endmodule

