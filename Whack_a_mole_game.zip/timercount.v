module timercount(
    input clk,           // from FPGA board
    input reset,         // reset button pressed
    output [4:0] count   // 20-second timer
);

    wire clk_out;
    timerclock U1(clk, clk_out);  // get one second clock

    reg [4:0] current_count = 20; // initially setting the counter to 20

    always @(posedge clk_out) begin
        if (reset)
            current_count <= 20;
        else if (current_count == 0)
            current_count <= current_count;
        else if (current_count >= 1)
            current_count <= current_count - 1;
        else
            current_count <= current_count;
    end

    assign count = current_count;

endmodule
