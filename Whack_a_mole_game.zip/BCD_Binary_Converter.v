//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 24.10.2025 10:43:52
// Design Name: 
// Module Name: BCD_Binary_Converter
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module Shift_Add3_algorithim(
    input [3:0] in, //four inputs
    output reg [3:0] out //four outputs
    );
    
    always @(in)
    case(in)
        4'b0000:out<=4'b0000;
        4'b0001:out<=4'b0001;
        4'b0010:out<=4'b0010;
        4'b0011:out<=4'b0011;
        4'b0100:out<=4'b0100;
        4'b0101:out<=4'b1000;
        4'b0110:out<=4'b1001;
        4'b0111:out<=4'b1010;
        4'b1000:out<=4'b1011;
        4'b1001:out<=4'b1100;  
        default:out<=4'b0000;  
    endcase
endmodule

module BCD_Binary_Converter(
    input [7:0] A,
    output [3:0] ones,
    output [3:0] tens,
    output [1:0] hundreds
    );
    //Follow the block diagram
    wire [3:0] c1,c2,c3,c4,c5,c6,c7; //declaring the data lines coming out of shift_Add3 module
    wire [3:0] d1,d2,d3,d4,d5,d6,d7; //declaring the data lines going into shift_Add3 module
    
    assign d1={1'b0,A[7:5]};
    assign d2={c1[2:0],A[4]};
    assign d3={c2[2:0],A[3]};
    assign d4={c3[2:0],A[2]};
    assign d5={c4[2:0],A[1]};
    assign d6={1'b0,c1[3],c2[3],c3[3]};
    assign d7={c6[2:0],c4[3]};
    
    //instantiate shift_Add3_algorithim
    
    Shift_Add3_algorithim U1 (d1,c1);
    Shift_Add3_algorithim U2 (d2,c2);
    Shift_Add3_algorithim U3 (d3,c3);
    Shift_Add3_algorithim U4 (d4,c4);
    Shift_Add3_algorithim U5 (d5,c5);
    Shift_Add3_algorithim U6 (d6,c6);
    Shift_Add3_algorithim U7 (d7,c7);
    
    assign ones={c5[2:0],A[0]};
    assign tens={c7[2:0],c5[3]};
    assign hundreds={c6[3],c7[3]};
    
endmodule
