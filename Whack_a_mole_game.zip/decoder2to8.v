//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 24.10.2025 12:59:46
// Design Name: 
// Module Name: decoder2to4
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module decoder2to8 (
    input [1:0] en,       // 2-bit select input for right displays
    output reg [7:0] an    // 8 displays (active-low)
);
    always @(en) begin
        case(en)
            2'b00: an = 8'b1111_1110; // Rightmost display ON
            2'b01: an = 8'b1111_1101; // 2nd from right ON
            2'b10: an = 8'b1111_1011; // 3rd from right ON
            2'b11: an = 8'b1111_0111; // 4th from right ON
            default: an = 8'b1111_1111; // All OFF
        endcase
    end
endmodule
