`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 24.10.2025 11:56:30
// Design Name: 
// Module Name: two_bit_counter
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module two_bit_counter(
    input clk, //slow clock
    output reg [1:0] Q = 0 //initialize output directly
    );
    
    always @(posedge clk) //when positive edge of the clock arrives, counter goes up by 1
    begin
        Q <= Q + 1;
    end

endmodule