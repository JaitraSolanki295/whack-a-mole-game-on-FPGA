`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 24.10.2025 11:42:38
// Design Name: 
// Module Name: ledblink
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module Slow_Clock(
    input clk_in,//input clock which is 100Mhz from fpga board
    output reg clk_out//slow clock at 100Hz frequency
    
);
    reg [20:0] count = 0; //2 power 20 
    
    always @(posedge clk_in)
    begin
    count <= count + 1;
    if (count == 50_000)
    begin
        count <= 0;
        clk_out <= ~clk_out;
    end
    end
endmodule

